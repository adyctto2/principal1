<?php

use Illuminate\Database\Seeder;
use App\Testimonios;
class TestimoniosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    }
}
