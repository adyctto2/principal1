<?php $__env->startSection('contenidoBiowell'); ?>
<div class="row">
    <div class="col-md-8">
        <h1><?php echo e($datos->nombre); ?></h1>
    </div>
    <div class="col-md-2">
        <a href="<?php echo e(route('ep',['id' =>  $datos->id])); ?>" class="btn btn-success btn-block boton-crear">Editar</a>
    </div>
    <div class="col-md-2">
        <a href="<?php echo e(route('listar')); ?>" class="btn btn-warning btn-block boton-crear">Volver</a>
    </div>
</div>
<img src="<?php echo e($datos->imagen); ?>" class="img-responsive img-thumbnail" alt="">
<h3>Precio : <?php echo e($datos->costo); ?> $us.</h3>
<h3>Descripción:</h3>
<p><?php echo e($datos->descripcion); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.biowell', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>