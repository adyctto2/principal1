<?php $__env->startSection('contenidoBiowell'); ?>
<h1>Actualizar producto</h1>
    <form action="<?php echo e(route('creartest')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" class="form-control" placeholder="Nombre" required name="nombre" id="nombre">
        </div>
        <div class="form-group">
            <label for="profesion">Profesion</label>
            <input type="text" class="form-control" placeholder="Profesion" required name="profesion" id="profesion">
        </div>
        <div class="form-group">
            <label for="testimonio">Testimonio</label>
            <textarea name="testimonio" id="testimonio" rows="3" class="form-control" placeholder="Testimonio"></textarea>
        </div>
        <div class="form-group">
            <label for="id_producto">Producto</label>
            <select name="id_producto" id="id_producto">
                <option value="0">Ninguno</option>
                <?php
                    $v = \App\Productos::all();
                ?>
                <?php $__currentLoopData = $v; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $va): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($va->id); ?>"><?php echo e($va->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="imagen">Foto de la persona</label>
            <input type="file" name="imagen" id="imagen" placeholder="foto de la persona" accept="image/*" >
        </div>
        <div class="form-group">
            <div class="row">
                <div class="col-md-6">
                    <input type="submit" value="Guardar Producto" name="guardar" class="btn btn-primary btn-block">

                </div>
                <div class="col-md-6">
                    <a href="<?php echo e(route('ltest')); ?>" class="btn btn-danger btn-block">Cancelar</a>

                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.biowell', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>