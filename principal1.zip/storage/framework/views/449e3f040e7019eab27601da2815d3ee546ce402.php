<?php $__env->startSection('contenidoBiowell'); ?>
<h1>Lista de reservas</h1>
<div class="row">
    <div class="col-md-12">
        <input type="text" placeholder="Buscar" class="form-control boton-crear">
    </div>
</div>
<div>
    <table class="table table-hover">
        <thead>
            <tr class="active">
                <th>N°</th>
                <th>Nombre</th>
                <th>Producto</th>
                <th>Fecha</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr <?php if($d->estado == 0 ): ?> class="info" <?php endif; ?>>
                <th><?php echo e($d->id); ?></th>
                <th><?php echo e($d->nombre); ?></th>
                <th><?php echo e($d->id_producto); ?></th>
                <th><?php echo e($d->fecha); ?></th>
                <th><a href="<?php echo e(route('vr',['id' =>  $d->id])); ?>">Ver</a></th>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.biowell', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>