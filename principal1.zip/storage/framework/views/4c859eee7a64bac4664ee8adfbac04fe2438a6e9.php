<?php $__env->startSection('contenidoBiowell'); ?>
<h1>Lista de productos</h1>
<div class="row">
    <div class="col-md-9">
        <input type="text" placeholder="Buscar" class="form-control boton-crear">
    </div>
    <div class="col-md-3 boton-crear">
        <a href="<?php echo e(route('cp')); ?>" class="btn btn-primary btn-block">Crear Producto</a>
    </div>
</div>
<div>
    <table class="table table-hover">
        <thead>
            <tr class="active">
                <th>N°</th>
                <th>Nombre</th>
                <th>Detalle</th>
                <th>Costo</th>
                <th></th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($d->id); ?></th>
                <th><?php echo e($d->nombre); ?></th>
                <th><?php echo e($d->descripcion); ?></th>
                <th><?php echo e($d->costo); ?></th>
                <th><a href="<?php echo e(route('ep',['id' =>  $d->id])); ?>">Editar</a></th>
                
                <th>
                    <form action="<?php echo e(route('borrarp',['id' =>  $d->id])); ?>" method="post">
                            <?php echo method_field('delete'); ?>

                            <?php echo csrf_field(); ?>

                        <input type="submit" value="eliminar">
                    </form>
                <th><a href="<?php echo e(route('vp',['id' =>  $d->id])); ?>">Ver</a></th>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.biowell', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>