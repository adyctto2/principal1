<?php $__env->startSection('contenidoBiowell'); ?>

<h1><?php echo e($datos->nombre); ?></h1>
<h3>Correo Electronico: <strong><?php echo e($datos->email); ?></strong></h3>    
<h3>Asunto: <strong><?php echo e($datos->asunto); ?></strong></h3>    
<h3>Fecha: <strong><?php echo e($datos->fecha); ?></strong></h3> 
<hr>
<h2>Mensaje:</h2>
<p><?php echo e($datos->mensaje); ?></p>
<div class="row">
    <div class="col-md-6"><a href="<?php echo e(route('ecm',['id' =>  $datos->id])); ?>" class="btn btn-success btn-block">Responder</a></div>
    <div class="col-md-6"><a href="<?php echo e(route('msj')); ?>" class="btn btn-warning btn-block">Volver</a></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.biowell', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>