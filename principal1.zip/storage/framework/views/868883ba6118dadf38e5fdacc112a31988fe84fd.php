<?php $__env->startSection('contenidoBiowell'); ?>
<h1>Lista de Preguntas</h1>
<div class="row">
    <div class="col-md-9">
        <input type="text" placeholder="Buscar" class="form-control boton-crear">
    </div>
    <div class="col-md-3 boton-crear">
        <a href="<?php echo e(route('cpreg')); ?>" class="btn btn-primary btn-block">Crear Pregunta</a>
    </div>
</div>
<div>
    <table class="table table-hover">
        <thead>
            <tr class="active">
                <th>N°</th>
                <th>Pregunta</th>
                <th>Respuesta</th>
                <th>Categoria</th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($d->id); ?></th>
                <th><?php echo e($d->pregunta); ?></th>
                <th><?php echo e($d->respuesta); ?></th>
                <?php
                 $var = \App\Category::where('id','=',$d->id_categoria)->first();
                ?>
                
                <th><?php echo e($var->nombre_cat); ?></th>
                <th><a href="<?php echo e(route('epreg',['id' =>  $d->id])); ?>">Editar</a></th>
                
                <th>
                    <form action="<?php echo e(route('bpreg',['id' =>  $d->id])); ?>" method="post">
                            <?php echo method_field('delete'); ?>

                            <?php echo csrf_field(); ?>

                        <input type="submit" value="eliminar">
                    </form>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.biowell', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>