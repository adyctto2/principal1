<?php $__env->startSection('contenidoBiowell'); ?>
<h1>Actualizar producto</h1>
    <form action="<?php echo e(route('actpreg')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="pregunta">Pregunta</label>
            <input type="text" class="form-control" placeholder="Pregunta" required name="pregunta" id="pregunta" value="<?php echo e($id->pregunta); ?>">
        </div>
        <div class="form-group">
            <label for="pregunta">Respuesta</label>
            <textarea name="respuesta" id="respuesta"  rows="5" class="form-control"><?php echo e($id->respuesta); ?></textarea>
        </div>
        <div class="form-group">
            <select class="form-control" name="id_categoria">
                <?php
                 $info = \App\Category::all();
                ?>
                <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($i->id); ?>" <?php if($i->id == $id->id_categoria): ?> selected <?php endif; ?>><?php echo e($i->nombre_cat); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
        </div>
        <div class="form-group">
            <label for="id">No modificar este campo</label>    
            <input type="number" class="form-control" required name="id" id="id" value="<?php echo e($id->id); ?>">
        
        </div>
        <div class="form-group">
            <div class="row">
                <div class="col-md-6">
                    <input type="submit" value="Guardar Producto" name="guardar" class="btn btn-primary btn-block">

                </div>
                <div class="col-md-6">
                    <a href="<?php echo e(route('lpreg')); ?>" class="btn btn-danger btn-block">Cancelar</a>

                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.biowell', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>