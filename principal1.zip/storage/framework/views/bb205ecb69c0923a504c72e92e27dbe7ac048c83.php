<?php $__env->startSection('contenidoBiowell'); ?>

<h1><?php echo e($datos->nombre); ?></h1>
<h3>Correo Electronico: <strong><?php echo e($datos->email); ?></strong></h3>    
<h3>Telefono: <strong><?php echo e($datos->telefono); ?></strong></h3>    
<h3>Pais: <strong><?php echo e($datos->pais); ?></strong></h3>    
<h3>Fecha de reserva: <strong><?php echo e($datos->fecha); ?></strong></h3> 
<hr>
<h2>Detalle del producto</h2>
<h3>Nombre: <strong><?php echo e($prod->nombre); ?></strong></h3>
<h3>Costo: <strong><?php echo e($prod->costo); ?></strong></h3>
<div class="row">
    <div class="col-md-6"><a href="<?php echo e(route('ecr',['id' =>  $datos->id])); ?>" class="btn btn-success btn-block">Responder</a></div>
    <div class="col-md-6"><a href="<?php echo e(route('rs')); ?>" class="btn btn-warning btn-block">Volver</a></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.biowell', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>