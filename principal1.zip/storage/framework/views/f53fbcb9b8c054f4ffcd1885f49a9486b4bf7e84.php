<?php $__env->startSection('contenidoBiowell'); ?>
<h1>Lista de productos</h1>
<div class="row">
    <div class="col-md-9">
        <input type="text" placeholder="Buscar" class="form-control boton-crear">
    </div>
    <div class="col-md-3 boton-crear">
        <a href="<?php echo e(route('ctest')); ?>" class="btn btn-primary btn-block">Crear Producto</a>
    </div>
</div>
<div>
    <table class="table table-hover">
        <thead>
            <tr class="active">
                <th>N°</th>
                <th>Nombre</th>
                <th>Profesion</th>
                <th>Testimonio</th>
                <th>Fecha</th>
                <th>Producto</th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($d->id); ?></th>
                <th><?php echo e($d->nombre); ?></th>
                <th><?php echo e($d->profesion); ?></th>
                <th><?php echo e($d->testimonio); ?></th>
                <?php
                    $dat = \App\Productos::where('id','=',$d->id_producto)->first();
                    if(count($dat)>=0)
                        $respuesta = $dat->nombre;
                    else
                        $respuesta = "ninguno";
                ?>
                <th><?php echo e($respuesta); ?></th>
                <th><a href="<?php echo e(route('etest',['id' =>  $d->id])); ?>">Editar</a></th>
                
                <th>
                    <form action="<?php echo e(route('btest',['id' =>  $d->id])); ?>" method="post">
                            <?php echo method_field('delete'); ?>

                            <?php echo csrf_field(); ?>

                        <input type="submit" value="eliminar">
                    </form>
                </th>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.biowell', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>