<?php $__env->startSection('contenidoBiowell'); ?>
<h1>Actualizar producto</h1>
    <form action="<?php echo e(route('acttest')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" class="form-control" placeholder="Nombre" required name="nombre" id="nombre" value ="<?php echo e($id->nombre); ?>">
        </div>
        <div class="form-group">
            <label for="profesion">Profesion</label>
            <input type="text" class="form-control" placeholder="Profesion" required name="profesion" id="profesion" value ="<?php echo e($id->profesion); ?>">
        </div>
        <div class="form-group">
            <label for="testimonio">Testimonio</label>
            <textarea name="testimonio" id="testimonio" rows="3" class="form-control" placeholder="Testimonio"><?php echo e($id->testimonio); ?></textarea>
        </div>
        <div class="form-group">
            <label for="id_producto">Producto</label>
            <select name="id_producto" id="id_producto" class="form-control">
                <?php
                    $v = \App\Productos::all();
                ?>
                <?php $__currentLoopData = $v; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $va): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($va->id); ?>" <?php if($va->id == $id->id_producto): ?> selected <?php endif; ?>><?php echo e($va->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="imagen">Imagen del producto</label>
            <input type="file" name="imagen" id="imagen" placeholder="foto de la persona" accept="image/*" >
        </div>
        <div class="form-group">
            <label for="id">No modificar este campo</label>
            <input type="text" class="form-control" placeholder="id" required name="id" id="id" value ="<?php echo e($id->id); ?>">
        </div>
        <div class="form-group">
            <div class="row">
                <div class="col-md-6">
                    <input type="submit" value="Guardar Producto" name="guardar" class="btn btn-primary btn-block">

                </div>
                <div class="col-md-6">
                    <a href="<?php echo e(route('ltest')); ?>" class="btn btn-danger btn-block">Cancelar</a>

                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.biowell', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>